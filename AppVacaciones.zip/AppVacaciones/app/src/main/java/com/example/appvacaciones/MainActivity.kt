package com.example.appvacaciones

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.MediaController
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.camera.core.CameraSelector
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.model.Marker
import com.google.firebase.firestore.GeoPoint
import java.io.File
import java.lang.Exception
import java.time.LocalDateTime
import kotlin.math.log


enum class pantallaActual{
    FORM,
    CAMARA
}

class CamaraViewmodel : ViewModel(){
    val pantallaActual = mutableStateOf(pantallaActual.FORM)
    var permisoCamara:() ->Unit={}
    val latitud = mutableStateOf(0.0)
    val longitud = mutableStateOf(0.0)
    var permisoUbicacionok:()->Unit = {}

    companion object {
        val latitud: Any
    }


}


private val MapView.TileSourceFactory: Any
    get() {}
val nombre = mutableStateOf("")
    val foto = mutableStateOf<Uri?>(null)

    companion object {
        val foto: Any
    }
}

class MainActivity : ComponentActivity() {
    val camaraViewmodel:CamaraViewmodel by viewModels()
    val Formvmodel: Formvmodel by viewModels()

    lateinit var cameraController:LifecycleCameraController
    val lanzadorPermisos = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){
        if (it[android.Manifest.permission.CAMERA]?:false){
           camaraViewmodel.permisoCamara()
        }
        if(
            (it[android.Manifest.permission.ACCESS_FINE_LOCATION]?:false)or
            (it[android.Manifest.permission.ACCESS_COARSE_LOCATION]?:false)){
            Formvmodel.permisoUbicacionok()
        }else{
           Log.v("lanzadorPermisos","denegado")
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        cameraController = LifecycleCameraController(this)
        cameraController.bindToLifecycle(this)
        cameraController.cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

        setContent {

            Camara(lanzadorPermisos, cameraController)



        }
    }
}





@Composable
fun Camara(lanzadorPermisos: ActivityResultLauncher<Array<String>>,cameraController:LifecycleCameraController) {
    val camaraViewmodel: CamaraViewmodel = viewModel()
    val contexto = LocalContext.current
//val appVm:AppVm = viewModel()
    when (camaraViewmodel.pantalla.value) {
        pantalla.FORM -> {
            pantallaFormulario()
        }

        pantalla.CAMARA -> {
            pantallaCameraUi(lanzadorPermisos, cameraController)
        }
    }
    Column {


        Button(onClick = {

            camaraViewmodel.permisoUbicacionok = {
                conseguirUbicacion(contexto) {
                    camaraViewmodel.latitud.value = it.latitude
                    camaraViewmodel.longitud.value = it.latitude
                }
            }

            lanzadorPermisos.launch(
                arrayOf(
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
            conseguirUbicacion(contexto) {
                camaraViewmodel.latitud.value = it.latitude
                camaraViewmodel.longitud.value = it.latitude
            }
        }) {
            Text("Ubicacion")
        }
        Text("Lat:${CamaraViewmodel.latitud.value} long:${CamaraViewmodel.latitud.value}")
        spacer(Modifier.height(100.dp))
        AndroidView(factory = {
            MapView(it).apply{
           setTileSource(TileSourceFactory.MAPNIK)
                org.osmdroid.config.Configuration.getInstance().userAgentValue = contexto.packageName
                controller.setZoom(15)
            }

        }, update = {

            it.overlays.removeIf{true}
            it.invalidate()
            val geopoint = GeoPoint(camaraViewmodel.latitud.value,camaraViewmodel.longitud.value)
            it.controller.AnimateTo(geopoint)

            val marcador = Marker(it)
            marcador.position =GeoPoint
            marcador.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_CENTER)
            it.overlays.add(marcador)
        }
        )


    }
}

class permisoExcepcion(mensaje:String):Exception(mensaje)


fun conseguirUbicacion(contexto: Context,onSuccess:(ubicacion:Location)->Unit){
    try {
        val servicio = LocationServices.getFusedLocationProviderClient(contexto)
       val tarea = servicio.getCurrentLocation(
            Priority.PRIORITY_HIGH_ACCURACY,
            null)
        tarea.addOnSuccessListener {
            onSuccess(it)
        }
    }catch (se:SecurityException){
throw permisoExcepcion("No tiene permiso de Ubicacion")
    }

}

fun generardatos():String = LocalDateTime.now().toString().replace(Regex("T:.-"),"").substring(0,16)


fun crearArchivo(contexto: Context):File = File(contexto.getExternalFilesDir(Enviroment.DIRECTORY PICTURES),
    ""
    )

fun tomarFoto(cameraController: LifecycleCameraController,
              archivo:File,
              contexto:Context,
              onImagenGuardada:(uri:Uri)->Unit
){
    val opciones = OutputFileOptions.Builder(archivo).build()
    cameraController.takePicture(
        opciones,
        ContextCompat.getMainExecutor(contexto),
        object: OneImageSavedCallback{
            override fun OneImageSaved(outputFileResults:ImageCapture.OutputFileResults){
              outputFileResults.savedUri?.let{
                  onImagenGuardada(it)
              }

        }

            override fun onError(exception: ImageCaptureExecption){
                log.e("capturarFotografia:: OnImageSavedCallback::onError")
            }
        }


    )
}


fun urImg(uri:Uri,contexto:Context)=BitmapFactory.decodeStream(contexto.contentResolver.openInputStream(uri)).asImageBitmap()

@Composable
fun pantallaFormulario() {
    val appVm: ViewModel = viewModel()
    val Formvmodel: Formvmodel  = viewModel()
    val contexto = LocalContext.current
    Column() {
        Button(onClick = {
            appVm.pantalla.value = pantalla.CAMARA
        }) {
            Text("")
        }

        Formvmodel.foto.value?.let{
            Image(
                painter = BitmapPainter(urImg(it,contexto)),
                contentDescription = "Imagen capturada desde Camara"

            )
        }


    }
}

@Composable
fun pantallaCameraUi(
    lanzadorPermisos: ActivityResultLauncher<Array<String>>,
    cameraController: LifecycleCameraController
) {
    val contexto = LocalContext.current
    val appVm:AppVm = viewModel()
    lanzadorPermisos.launch(arrayOf(android.Manifest.permission.CAMERA))
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = {
            PreviewView(it).apply {
                controller = cameraController
            }
        }
    )
    Button(onClick = {
        tomarFoto(
            cameraController, crearArchivo(contexto),
            contexto
        ) {
            // Código para manejar la acción después de tomar la foto
        }
        Formvmodel.foto.value = it
    }) {
        Text("Capturar")
    }
}




